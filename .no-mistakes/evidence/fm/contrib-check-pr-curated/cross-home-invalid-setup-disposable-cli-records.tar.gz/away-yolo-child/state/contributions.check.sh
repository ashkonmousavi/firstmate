#!/usr/bin/env bash
export FM_HOME=/home/tegris/.no-mistakes/worktrees/1e7d3bc48f31/01M6DEE8N3FPKKWF8CNR4SPFE0/.contrib-live-validation/tmp/fm-contributions.LALeTp/away-yolo-child
export FM_STATE_OVERRIDE=/home/tegris/.no-mistakes/worktrees/1e7d3bc48f31/01M6DEE8N3FPKKWF8CNR4SPFE0/.contrib-live-validation/tmp/fm-contributions.LALeTp/away-yolo-child/state
export FM_DATA_OVERRIDE=/home/tegris/.no-mistakes/worktrees/1e7d3bc48f31/01M6DEE8N3FPKKWF8CNR4SPFE0/.contrib-live-validation/tmp/fm-contributions.LALeTp/away-yolo-child/data
exec /home/tegris/.no-mistakes/worktrees/1e7d3bc48f31/01M6DEE8N3FPKKWF8CNR4SPFE0/bin/fm-contributions.sh poll
