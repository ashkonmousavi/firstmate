#!/usr/bin/env bash
export FM_HOME=/tmp/fm-contributions.RpJeBL/verdict-roundtrip
export FM_STATE_OVERRIDE=/tmp/fm-contributions.RpJeBL/verdict-roundtrip/state
export FM_DATA_OVERRIDE=/tmp/fm-contributions.RpJeBL/verdict-roundtrip/data
exec /home/tegris/.no-mistakes/worktrees/1e7d3bc48f31/01M6DEE8N3FPKKWF8CNR4SPFE0/bin/fm-contributions.sh poll
