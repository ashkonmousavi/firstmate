#!/usr/bin/env bash
set -eu
E=/home/zcrew/.no-mistakes/evidence/01M4WPYF0ZEX1CQ8BVJAMKNZFT/round2/failclosed
export FM_HERDR_LAB_STATE_DIR="$PWD/.test-herdr-lab/state"
export PATH="$PWD/.test-herdr-lab/transport:$PATH"
export LAB_INPUT_FIFO="$PWD/.test-herdr-lab/input" LAB_PTY_LOG="$E/viewer.ansi"
S=$(bin/fm-herdr-lab.sh name mouse-scroll)
printf "%s" "$S" > .test-herdr-lab/session
bin/fm-herdr-lab.sh provision "$S"
bin/fm-herdr-lab.sh run "$S" workspace create --cwd "$PWD" --label scrolled-proof --no-focus >/dev/null
bin/fm-herdr-lab.sh run "$S" pane run w1:p1 "CLAUDE_CODE_ENABLE_PROMPT_SUGGESTION=false claude --dangerously-skip-permissions" >/dev/null
. bin/fm-herdr-lab.sh
fm_herdr_lab_viewer_launcher_path() { printf '%s/.test-herdr-lab/viewer.py' "$PWD"; }
fm_herdr_lab_viewer_start "$S"
lab() { bin/fm-herdr-lab.sh run "$S" "$@"; }
trap 'bin/fm-herdr-lab.sh teardown "$S"' EXIT
sleep 8
echo "History: $(bash .test-herdr-lab/probe.sh fm_backend_herdr_send_text_submit 'Print 80 numbered lines saying HISTORY ROW. Do not use tools.' 3 0.4 0.4)"
sleep 25
lab pane scroll w1:p1 70
sleep 1
lab pane get w1:p1 > "$E/scrolled-pane.json"
lab pane read w1:p1 --source visible > "$E/scrolled-visible.txt"
lab pane read w1:p1 --source recent --lines 200 > "$E/scrolled-bottom.txt"
cp "$E/viewer.ansi" "$E/scrolled-viewer.ansi"
echo "Confirmed offset: $(jq -r '.result.pane.scroll.offset_from_bottom' "$E/scrolled-pane.json")"
echo "Scrolled state: $(bash .test-herdr-lab/probe.sh fm_backend_herdr_composer_state)"
sleep 1
echo "Base scrolled state: $(PROBE_BACKEND=.test-herdr-lab/base/bin/backends/herdr.sh bash .test-herdr-lab/probe.sh fm_backend_herdr_composer_state)"
echo "Shutdown during composer read: $(LAB_STOP_AFTER_SCROLL_PROBE=1 bash .test-herdr-lab/probe.sh fm_backend_herdr_composer_state)"
