#!/usr/bin/env bash
set -eu
E=/home/zcrew/.no-mistakes/evidence/01M4WPYF0ZEX1CQ8BVJAMKNZFT/round2
export FM_HERDR_LAB_STATE_DIR="$PWD/.test-herdr-lab/state"
export PATH="$PWD/.test-herdr-lab/transport:$PATH"
export LAB_INPUT_FIFO="$PWD/.test-herdr-lab/input" LAB_PTY_LOG="$E/exit-viewer.ansi"
S=$(bin/fm-herdr-lab.sh name exit-proof); printf '%s' "$S" > .test-herdr-lab/session
bin/fm-herdr-lab.sh provision "$S"
trap 'bin/fm-herdr-lab.sh teardown "$S"' EXIT
. bin/fm-herdr-lab.sh
fm_herdr_lab_viewer_launcher_path() { printf '%s/.test-herdr-lab/viewer.py' "$PWD"; }
lab() { bin/fm-herdr-lab.sh run "$S" "$@"; }
lab workspace create --cwd "$PWD" --label exit-proof --no-focus >/dev/null
lab pane run w1:p1 'CLAUDE_CODE_ENABLE_PROMPT_SUGGESTION=false claude --dangerously-skip-permissions' >/dev/null
fm_herdr_lab_viewer_start "$S"
sleep 8
lab pane send-text w1:p1 /exit >/dev/null
sleep 2
lab pane get w1:p1 > "$E/typed-exit-pane.json"
lab pane read w1:p1 --source visible > "$E/typed-exit-visible.txt"
lab pane read w1:p1 --source recent --lines 200 > "$E/typed-exit-recent.txt"
cp "$E/exit-viewer.ansi" "$E/typed-exit-viewer.ansi"
echo "Typed state: $(bash .test-herdr-lab/probe.sh fm_backend_herdr_composer_state)"
echo "Typed content: $(bash .test-herdr-lab/probe.sh fm_backend_herdr_composer_content)"
lab pane send-keys w1:p1 ctrl+u >/dev/null
sleep 1
lab pane scroll w1:p1 0 >/dev/null
sleep 1
sleep 1
lab pane scroll w1:p1 0 >/dev/null
sleep 1
echo "Target submit: $(bash .test-herdr-lab/probe.sh fm_backend_herdr_send_text_submit /exit 3 0.4 1.2)"
lab pane get w1:p1 > "$E/target-exit-pane.json"
sleep 2
lab agent get w1:p1 > "$E/popup-agent-after.json" 2>&1 || true
lab pane read w1:p1 --source visible > "$E/popup-exit-after.txt"
