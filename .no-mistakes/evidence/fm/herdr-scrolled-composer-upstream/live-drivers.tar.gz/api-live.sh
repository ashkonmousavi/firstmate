#!/usr/bin/env bash
set -eu
E=/home/zcrew/.no-mistakes/evidence/01M4WPYF0ZEX1CQ8BVJAMKNZFT
export FM_HERDR_LAB_STATE_DIR="$PWD/.test-herdr-lab/state"
export PATH="$PWD/.test-herdr-lab/transport:$PATH"
export LAB_INPUT_FIFO="$PWD/.test-herdr-lab/input" LAB_PTY_LOG="$E/viewer.ansi"
S=$(bin/fm-herdr-lab.sh name mouse-scroll)
printf "%s" "$S" > .test-herdr-lab/session
bin/fm-herdr-lab.sh provision "$S"
bin/fm-herdr-lab.sh run "$S" workspace create --cwd "$PWD" --label scrolled-proof --no-focus >/dev/null
bin/fm-herdr-lab.sh run "$S" pane run w1:p1 "CLAUDE_CODE_ENABLE_PROMPT_SUGGESTION=false claude --dangerously-skip-permissions" >/dev/null
. bin/fm-herdr-lab.sh
fm_herdr_lab_viewer_launcher_path() { printf '%s/.test-herdr-lab/viewer.py' "$PWD"; }
fm_herdr_lab_viewer_start "$S"
lab() { bin/fm-herdr-lab.sh run "$S" "$@"; }
trap 'bin/fm-herdr-lab.sh teardown "$S"' EXIT
sleep 8
echo "History: $(bash .test-herdr-lab/probe.sh fm_backend_herdr_send_text_submit 'Print 80 numbered lines saying HISTORY ROW. Do not use tools.' 3 0.4 0.4)"
sleep 15
lab pane scroll w1:p1 70
sleep 1
lab pane get w1:p1 > "$E/scrolled-pane.json"
lab pane read w1:p1 --source visible > "$E/scrolled-visible.txt"
lab pane read w1:p1 --source recent --lines 200 > "$E/scrolled-bottom.txt"
cp "$E/viewer.ansi" "$E/scrolled-viewer.ansi"
echo "Confirmed offset: $(jq -r '.result.pane.scroll.offset_from_bottom' "$E/scrolled-pane.json")"
echo "Scrolled state: $(bash .test-herdr-lab/probe.sh fm_backend_herdr_composer_state)"
sleep 1
echo "Delivery: $(bash .test-herdr-lab/probe.sh fm_backend_herdr_send_text_submit 'Reply exactly LAB_DOORBELL_OK. Do not use tools.' 3 0.4 0.4)"
sleep 15
lab pane read w1:p1 --source recent --lines 200 > "$E/doorbell-response.txt"
lab pane send-text w1:p1 KEEP_THIS_DRAFT >/dev/null
sleep 1
lab pane scroll w1:p1 70
sleep 1
lab pane get w1:p1 > "$E/draft-scrolled-pane.json"
echo "Draft state: $(bash .test-herdr-lab/probe.sh fm_backend_herdr_composer_state)"
echo "Draft content: $(bash .test-herdr-lab/probe.sh fm_backend_herdr_composer_content)"
echo "Draft delivery refusal: $(bash .test-herdr-lab/probe.sh fm_backend_herdr_send_text_submit 'MUST_NOT_APPEND' 3 0.4 0.4)"
lab pane read w1:p1 --source recent --lines 200 > "$E/draft-preserved.txt"
lab pane send-keys w1:p1 ctrl+u >/dev/null
sleep 1
lab pane scroll w1:p1 0
sleep 1
lab pane get w1:p1 > "$E/unscrolled-pane.json"
lab pane send-keys w1:p1 esc >/dev/null
sleep 2
echo "Before exit state: $(bash .test-herdr-lab/probe.sh fm_backend_herdr_composer_state)"
echo "Exit: $(bash .test-herdr-lab/probe.sh fm_backend_herdr_send_text_submit /exit 3 0.4 1.2)"
sleep 2
lab pane read w1:p1 --source visible > "$E/exit-screen.txt"
if lab agent get w1:p1 > "$E/exit-agent.json" 2>&1; then echo 'Agent still registered'; else echo 'Agent exited'; fi
