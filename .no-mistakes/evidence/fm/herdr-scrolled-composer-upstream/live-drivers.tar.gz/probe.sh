#!/usr/bin/env bash
export FM_HERDR_LAB_STATE_DIR="$PWD/.test-herdr-lab/state"
export PATH="$PWD/.test-herdr-lab/wrappers:$PATH"
unset HERDR_ENV HERDR_PANE_ID HERDR_TAB_ID HERDR_SOCKET_PATH HERDR_SESSION
. "${PROBE_BACKEND:-bin/backends/herdr.sh}"
TARGET="$(cat .test-herdr-lab/session):w1:p1"
fn=$1; shift
"$fn" "$TARGET" "$@"
